package com.domain;


public interface ProtocolAttr {
    int TCP = 0;
    int UDP = 1;
}
